<?php


namespace Composer\Repository;


class InstalledArrayRepository extends WritableArrayRepository implements InstalledRepositoryInterface
{
}
