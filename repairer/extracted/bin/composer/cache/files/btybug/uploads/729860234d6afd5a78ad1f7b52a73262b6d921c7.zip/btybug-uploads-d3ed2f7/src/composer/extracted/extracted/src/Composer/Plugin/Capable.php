<?php


namespace Composer\Plugin;


interface Capable
{


    public function getCapabilities();
}
