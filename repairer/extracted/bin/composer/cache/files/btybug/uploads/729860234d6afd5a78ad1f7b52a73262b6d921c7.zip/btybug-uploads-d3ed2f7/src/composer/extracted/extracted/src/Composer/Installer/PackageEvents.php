<?php


namespace Composer\Installer;


class PackageEvents
{


    const PRE_PACKAGE_INSTALL = 'pre-package-install';


    const POST_PACKAGE_INSTALL = 'post-package-install';


    const PRE_PACKAGE_UPDATE = 'pre-package-update';


    const POST_PACKAGE_UPDATE = 'post-package-update';


    const PRE_PACKAGE_UNINSTALL = 'pre-package-uninstall';


    const POST_PACKAGE_UNINSTALL = 'post-package-uninstall';
}
