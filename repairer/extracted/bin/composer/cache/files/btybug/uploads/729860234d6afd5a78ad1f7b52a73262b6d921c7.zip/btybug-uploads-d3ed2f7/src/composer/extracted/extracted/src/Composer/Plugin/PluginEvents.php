<?php


namespace Composer\Plugin;


class PluginEvents
{


    const INIT = 'init';


    const COMMAND = 'command';


    const PRE_FILE_DOWNLOAD = 'pre-file-download';
}
