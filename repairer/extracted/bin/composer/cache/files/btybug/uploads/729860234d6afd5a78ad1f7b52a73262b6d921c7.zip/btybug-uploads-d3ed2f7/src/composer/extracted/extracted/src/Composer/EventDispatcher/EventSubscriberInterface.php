<?php


namespace Composer\EventDispatcher;


interface EventSubscriberInterface
{


    public static function getSubscribedEvents();
}
