<?php


namespace Composer\Plugin\Capability;


interface CommandProvider extends Capability
{


    public function getCommands();
}
